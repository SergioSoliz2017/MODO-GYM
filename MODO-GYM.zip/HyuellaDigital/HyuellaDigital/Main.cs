﻿using DPFP;
using MySql.Data.MySqlClient;
using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Net.Http;
using System.Runtime.InteropServices.ComTypes;
using System.Security.Policy;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.ToolBar;

namespace HyuellaDigital
{
    public partial class Main : Form
    {
        private DPFP.Template Template;
        public Main()
        {
            InitializeComponent();
            this.StartPosition = FormStartPosition.CenterScreen;
            this.MaximizeBox = false;
        }

        private void Main_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (txtCi.Text.ToString() != "")
            {
                if (txtCi.Text.ToString().Length > 5) {
                    CapturarHuella capturar = new CapturarHuella();
                    capturar.OnTemplate += this.OnTemplate;
                    capturar.ShowDialog();
                }
                else
                {
                    MessageBox.Show("CI invalido", "MODO-GYM", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }

            }
            else
            {
                MessageBox.Show("Ingrece CI del usuario", "MODO-GYM", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            
        }

        private void OnTemplate(DPFP.Template template)
        {
            this.Invoke(new Function(delegate ()
            {
                Template = template;
                verificar.Enabled = (Template != null);
                if (Template != null)
                {
                    MessageBox.Show("Huella Escaneada Correctamente", "MODO-GYM", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                else
                {
                    MessageBox.Show("The fingerprint template is not valid. Repeat fingerprint enrollment.", "Fingerprint Enrollment");
                }
            }));
        }

        private async void enviar_Click(object sender, EventArgs e)
        {
            try
            {
                byte[] streamHuella = Template.Bytes;
                string url = "C:\\RegistrarHuella\\Huellas\\" + txtCi.Text.ToString() + ".txt";

                using (HttpClient client = new HttpClient())
                {
                    // Encabezado para la autenticación
                    var apiSecret = "SA1c2UCkQ5vMAf9Tc2aOIaTyO+Pg9XUZ/ZFUJBuMVpk=";

                    // Agregar el encabezado Api-Secret
                    client.DefaultRequestHeaders.Add("Api-Secret", apiSecret);

                    HttpResponseMessage response = await client.GetAsync("http://34.72.107.159/modo-gym-admin/public/api/usuario/" + txtCi.Text.ToString());

                    if (response.IsSuccessStatusCode)
                    {
                        // Si la petición es exitosa, guardar el archivo
                        File.WriteAllBytes(url, streamHuella);
                        _ = MessageBox.Show("Usuario registrado correctamente", "MODO-GYM", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        verificar.Enabled = false;
                        txtCi.Text = "";
                    }
                    else
                    {
                        // Si la petición no es exitosa, mostrar un mensaje de error
                        MessageBox.Show("Por favor habilite primero al usuario", "MODO-GYM", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void txtCi_TextChanged(object sender, EventArgs e)
        {
            
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }
    }
}
