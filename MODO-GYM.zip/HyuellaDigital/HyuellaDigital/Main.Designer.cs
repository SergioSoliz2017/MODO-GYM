﻿namespace HyuellaDigital
{
    partial class Main
    {
        /// <summary>
        /// Variable del diseñador necesaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpiar los recursos que se estén usando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben desechar; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido de este método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Main));
            this.label1 = new System.Windows.Forms.Label();
            this.txtCi = new System.Windows.Forms.TextBox();
            this.verificar = new System.Windows.Forms.Button();
            this.escanearHuella = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(112, 36);
            this.label1.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(0, 13);
            this.label1.TabIndex = 2;
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // txtCi
            // 
            this.txtCi.BackColor = System.Drawing.Color.White;
            this.txtCi.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txtCi.Font = new System.Drawing.Font("Race Sport", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtCi.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.txtCi.Location = new System.Drawing.Point(60, 88);
            this.txtCi.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.txtCi.Name = "txtCi";
            this.txtCi.Size = new System.Drawing.Size(609, 42);
            this.txtCi.TabIndex = 3;
            this.txtCi.Tag = "Ingrese CI";
            this.txtCi.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.txtCi.TextChanged += new System.EventHandler(this.txtCi_TextChanged);
            // 
            // verificar
            // 
            this.verificar.BackColor = System.Drawing.Color.White;
            this.verificar.BackgroundImage = global::HyuellaDigital.Properties.Resources.Guardar;
            this.verificar.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.verificar.Cursor = System.Windows.Forms.Cursors.Default;
            this.verificar.Enabled = false;
            this.verificar.FlatAppearance.BorderColor = System.Drawing.Color.White;
            this.verificar.FlatAppearance.BorderSize = 10;
            this.verificar.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Red;
            this.verificar.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Red;
            this.verificar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.verificar.Location = new System.Drawing.Point(369, 352);
            this.verificar.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.verificar.Name = "verificar";
            this.verificar.Size = new System.Drawing.Size(300, 100);
            this.verificar.TabIndex = 1;
            this.verificar.UseVisualStyleBackColor = false;
            this.verificar.Click += new System.EventHandler(this.enviar_Click);
            // 
            // escanearHuella
            // 
            this.escanearHuella.AccessibleRole = System.Windows.Forms.AccessibleRole.None;
            this.escanearHuella.BackColor = System.Drawing.Color.White;
            this.escanearHuella.BackgroundImage = global::HyuellaDigital.Properties.Resources.HuellaDigital;
            this.escanearHuella.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.escanearHuella.FlatAppearance.BorderColor = System.Drawing.Color.White;
            this.escanearHuella.FlatAppearance.BorderSize = 10;
            this.escanearHuella.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.escanearHuella.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(128)))));
            this.escanearHuella.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.escanearHuella.Font = new System.Drawing.Font("Race Sport", 7.874999F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.escanearHuella.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.escanearHuella.Location = new System.Drawing.Point(60, 352);
            this.escanearHuella.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.escanearHuella.Name = "escanearHuella";
            this.escanearHuella.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.escanearHuella.Size = new System.Drawing.Size(300, 100);
            this.escanearHuella.TabIndex = 0;
            this.escanearHuella.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.escanearHuella.UseVisualStyleBackColor = false;
            this.escanearHuella.Click += new System.EventHandler(this.button1_Click);
            // 
            // label2
            // 
            this.label2.BackColor = System.Drawing.Color.Transparent;
            this.label2.Enabled = false;
            this.label2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label2.Font = new System.Drawing.Font("Race Sport", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.White;
            this.label2.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.label2.Location = new System.Drawing.Point(63, 37);
            this.label2.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(601, 36);
            this.label2.TabIndex = 4;
            this.label2.Text = "Ingresar CI:";
            this.label2.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            this.label2.UseMnemonic = false;
            this.label2.Click += new System.EventHandler(this.label2_Click);
            // 
            // Main
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::HyuellaDigital.Properties.Resources._22380126353;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(722, 475);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.txtCi);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.verificar);
            this.Controls.Add(this.escanearHuella);
            this.DoubleBuffered = true;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.Name = "Main";
            this.Text = "MODO-GYM";
            this.Load += new System.EventHandler(this.Main_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button escanearHuella;
        private System.Windows.Forms.Button verificar;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtCi;
        internal System.Windows.Forms.Label label2;
    }
}

