﻿
using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Globalization;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml.Linq;
using static VerificarHuella.CapturarHuella;

namespace VerificarHuella
{
    public partial class ControlAsistencia : Form
    {
        public string usu_ci;
        private Timer timerCerrar;
        public ControlAsistencia()
        {
            InitializeComponent();
            this.StartPosition = FormStartPosition.CenterScreen;
            this.MaximizeBox = false;
        }

        private async Task subirBaseDatosAsync()
        {
            try
            {
                // URL de la API
                string apiUrl = "http://34.72.107.159/modo-gym-admin/public/api/registra-asistencia";

                // Cuerpo de la solicitud
                string requestBody = $"{{\"usu_ci\": \"{usu_ci}\"}}";

                // Cabecera Api-Secret
                string apiSecret = "SA1c2UCkQ5vMAf9Tc2aOIaTyO+Pg9XUZ/ZFUJBuMVpk=";

                // Configurar HttpClient con la cabecera Api-Secret
                using (var client = new HttpClient())
                {
                    client.DefaultRequestHeaders.Add("Api-Secret", apiSecret);

                    // Crear contenido de la solicitud con el cuerpo
                    var content = new StringContent(requestBody, Encoding.UTF8, "application/json");

                    // Realizar la solicitud POST
                    HttpResponseMessage response = await client.PostAsync(apiUrl, content);

                    // Verificar si la solicitud fue exitosa
                    if (response.IsSuccessStatusCode)
                    {
                        string responseData = await response.Content.ReadAsStringAsync();
                        JObject jsonResponse = JObject.Parse(responseData);
                        string data = jsonResponse["data"].Value<string>();
                        nomEstudiante.Text = data == "Asistencia ENTRADA" ? "Hola Bienvenido" : "Hasta luego";
                        imagen.Image = Properties.Resources.Bien;
                    }
                    else if (response.StatusCode == System.Net.HttpStatusCode.BadRequest)
                    {
                        nomEstudiante.Text = "Ya ha sido registrado";
                        imagen.Image = Properties.Resources.Mal; // Puedes cambiar a una imagen específica de error si lo deseas
                    }
                    else if (response.StatusCode == System.Net.HttpStatusCode.NotFound)
                    {
                        nomEstudiante.Text = "Usuario no encontrado";
                        imagen.Image = Properties.Resources.Mal;
                    }
                    else
                    {
                        nomEstudiante.Text = "Error desconocido al procesar la solicitud";
                        imagen.Image = Properties.Resources.Mal;
                    }
                    timerCerrar = new Timer();
                    timerCerrar.Interval = 3000;
                    timerCerrar.Tick += TimerCerrar_Tick;
                    timerCerrar.Start();
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error: {ex.Message}");
            }
        }
        private void ControlAsistencia_Load(object sender, EventArgs e)
        {
            Task task = subirBaseDatosAsync();
        }

        private void TimerCerrar_Tick(object sender, EventArgs e)
        {
            // Detener el temporizador para evitar que siga ejecutándose
            timerCerrar.Stop();

            // Cerrar la ventana
            this.Close();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label1_Click_1(object sender, EventArgs e)
        {

        }

        private void label1_Click_2(object sender, EventArgs e)
        {

        }

        private void imagen_Click(object sender, EventArgs e)
        {

        }

        private void label1_Click_3(object sender, EventArgs e)
        {

        }

        private void label1_Click_4(object sender, EventArgs e)
        {

        }
    }
}
