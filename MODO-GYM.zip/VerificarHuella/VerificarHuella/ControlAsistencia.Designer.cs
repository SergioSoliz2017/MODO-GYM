﻿namespace VerificarHuella
{
    partial class ControlAsistencia
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(ControlAsistencia));
            this.nomEstudiante = new System.Windows.Forms.Label();
            this.txtHabilitado = new System.Windows.Forms.Label();
            this.imageList1 = new System.Windows.Forms.ImageList(this.components);
            this.imagen = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.imagen)).BeginInit();
            this.SuspendLayout();
            // 
            // nomEstudiante
            // 
            this.nomEstudiante.Location = new System.Drawing.Point(84, 17);
            this.nomEstudiante.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.nomEstudiante.Name = "nomEstudiante";
            this.nomEstudiante.Size = new System.Drawing.Size(664, 56);
            this.nomEstudiante.TabIndex = 0;
            this.nomEstudiante.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            this.nomEstudiante.Click += new System.EventHandler(this.label1_Click);
            // 
            // txtHabilitado
            // 
            this.txtHabilitado.Location = new System.Drawing.Point(88, 343);
            this.txtHabilitado.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.txtHabilitado.Name = "txtHabilitado";
            this.txtHabilitado.Size = new System.Drawing.Size(660, 37);
            this.txtHabilitado.TabIndex = 2;
            this.txtHabilitado.Text = "Habilitado";
            this.txtHabilitado.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            this.txtHabilitado.Click += new System.EventHandler(this.label1_Click_2);
            // 
            // imageList1
            // 
            this.imageList1.ColorDepth = System.Windows.Forms.ColorDepth.Depth8Bit;
            this.imageList1.ImageSize = new System.Drawing.Size(16, 16);
            this.imageList1.TransparentColor = System.Drawing.Color.Transparent;
            // 
            // imagen
            // 
            this.imagen.Location = new System.Drawing.Point(256, 72);
            this.imagen.Margin = new System.Windows.Forms.Padding(4);
            this.imagen.Name = "imagen";
            this.imagen.Size = new System.Drawing.Size(320, 242);
            this.imagen.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.imagen.TabIndex = 3;
            this.imagen.TabStop = false;
            this.imagen.Click += new System.EventHandler(this.imagen_Click);
            // 
            // ControlAsistencia
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(12F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(824, 487);
            this.Controls.Add(this.imagen);
            this.Controls.Add(this.txtHabilitado);
            this.Controls.Add(this.nomEstudiante);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Name = "ControlAsistencia";
            this.Text = "ControlAsistencia";
            this.Load += new System.EventHandler(this.ControlAsistencia_Load);
            ((System.ComponentModel.ISupportInitialize)(this.imagen)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Label nomEstudiante;
        private System.Windows.Forms.Label txtHabilitado;
        private System.Windows.Forms.ImageList imageList1;
        private System.Windows.Forms.PictureBox imagen;
    }
}