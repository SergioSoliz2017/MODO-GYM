﻿namespace VerificarHuella
{
    partial class Form1
    {
        /// <summary>
        /// Variable del diseñador necesaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpiar los recursos que se estén usando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben desechar; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido de este método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.verificar = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // verificar
            // 
            this.verificar.BackgroundImage = global::VerificarHuella.Properties.Resources.Verificar;
            this.verificar.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.verificar.Location = new System.Drawing.Point(116, 472);
            this.verificar.Name = "verificar";
            this.verificar.Size = new System.Drawing.Size(529, 115);
            this.verificar.TabIndex = 0;
            this.verificar.TextAlign = System.Drawing.ContentAlignment.TopRight;
            this.verificar.UseVisualStyleBackColor = true;
            this.verificar.Click += new System.EventHandler(this.verificar_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(12F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::VerificarHuella.Properties.Resources._22380126353;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(749, 616);
            this.Controls.Add(this.verificar);
            this.DoubleBuffered = true;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "Form1";
            this.Text = "Verificar Huella";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button verificar;
    }
}

