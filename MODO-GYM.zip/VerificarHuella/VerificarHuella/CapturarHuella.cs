﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Runtime.InteropServices.ComTypes;
using System.Runtime.Remoting.Contexts;
using System.Windows.Forms;
using static VerificarHuella.CapturarHuella;
using System.Threading;

namespace VerificarHuella
{
    public partial class CapturarHuella : CaptureForm
    {
        private DPFP.Template Template;
        private DPFP.Verification.Verification Verificator;

     
        public void Verify(DPFP.Template template)
        {
            Template = template;
            ShowDialog();
        }

        protected override void Init()
        {
            base.Init();
            base.Text = "MODO-GYM";
            Verificator = new DPFP.Verification.Verification();     // Create a fingerprint template verificator
            UpdateStatus(0);
        }

        private void UpdateStatus(int FAR)
        {
            // Show "False accept rate" value
            SetStatus(String.Format("Tasa de aceptación falsa (FAR) = {0}", FAR));
        }

        protected override void Process(DPFP.Sample Sample)
        {
            base.Process(Sample);

            // Process the sample and create a feature set for the enrollment purpose.
            DPFP.FeatureSet features = ExtractFeatures(Sample, DPFP.Processing.DataPurpose.Verification);

            // Check quality of the sample and start verification if it's good
            // TODO: move to a separate task
            if (features != null)
            {
                // Compare the feature set with our template

                DPFP.Verification.Verification.Result result = new DPFP.Verification.Verification.Result();
                Stream stream;
                DPFP.Template template = new DPFP.Template();
                
                obtenerHuellas();
                foreach (var user in usuarios)
                {
                    stream = new MemoryStream(user.huella);
                    template = new DPFP.Template(stream);
                    Verificator.Verify(features, template, ref result);
                    UpdateStatus(result.FARAchieved);
                    ControlAsistencia control = new ControlAsistencia();

                    if (result.Verified)
                    {
                        control.usu_ci = user.CI;
                        control.ShowDialog();
                        break;
                    }
                }

            }
        }

        List<Usuario> usuarios;

        public object Newtonsoft { get; private set; }

        public class Usuario
        {
            public string CI { get; set; }
            public byte[] huella { get; set; }
        }
        private void obtenerHuellas()
        {

            usuarios = new List<Usuario>();

            string directorio = "C:\\RegistrarHuella\\Huellas";

            // Verificar si el directorio existe
            if (Directory.Exists(directorio))
            {
                // Obtener la lista de archivos en el directorio
                string[] archivos = Directory.GetFiles(directorio);

                // Iterar sobre cada archivo
                foreach (string archivo in archivos)
                {
                    // Leer los bytes del archivo
                    byte[] bytes = File.ReadAllBytes(archivo);

                    // Crear un nuevo objeto Usuario
                    Usuario usuario = new Usuario();
                    usuario.CI = Path.GetFileNameWithoutExtension(archivo); // Obtener el nombre del archivo sin extensión como ci
                    usuario.huella = bytes;

                    // Agregar el objeto Usuario a la lista de usuarios
                    usuarios.Add(usuario);
                }
            }
            else
            {
                Console.WriteLine("El directorio no existe: " + directorio);
            }

        }
        public CapturarHuella()
        {
            InitializeComponent();
        }

        private void CapturarHuella_Load(object sender, EventArgs e)
        {

        }
    }
}