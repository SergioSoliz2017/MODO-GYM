﻿using System;
using System.Windows.Forms;

namespace VerificarHuella
{
    internal static class Program
    {
        [STAThread]
        static void Main(string[] args)
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);

            // Creamos un nuevo BackgroundWorker
            var worker = new System.ComponentModel.BackgroundWorker();

            // Creamos el formulario
            var form = new Form1();

            // Establecemos el BackgroundWorker en la propiedad del formulario
            form.Worker = worker;

            Application.Run(form);
        }
    }
}
